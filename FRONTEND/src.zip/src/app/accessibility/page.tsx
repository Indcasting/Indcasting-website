"use client";

import { useEffect, useState } from "react";
import "./accessibility.css";

export default function AccessibilityPage() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved === "dark") {
      setDark(true);
      document.documentElement.classList.add("dark");
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <main className="accessibility-page">
      <section className="accessibility-hero">
        <div className="accessibility-hero-inner">
          <span className="accessibility-eyebrow">
            INDCASTING
          </span>

          <h1>Accessibility</h1>

          <p>
            Creating an inclusive platform where everyone can discover
            opportunities, connect with talent and participate in the
            creative industry.
          </p>
        </div>
      </section>

      <section className="accessibility-content">
        <div className="accessibility-container">
          <div className="accessibility-intro">
            <p>
              IndCasting, a product of Ekagracit Technologies Private
              Limited, is committed to making its platform accessible
              and usable for as many people as possible.
            </p>

            <p>
              We believe that accessibility is an important part of
              creating an inclusive casting and talent-discovery
              platform. We continuously work to improve the experience
              for users with different abilities, devices and ways of
              interacting with technology.
            </p>
          </div>

          <div className="accessibility-section">
            <h2>Our Commitment</h2>
            <p>
              We aim to design and develop IndCasting with accessibility
              in mind. This includes working toward clear navigation,
              readable content, appropriate colour contrast and
              interfaces that can be used across different devices and
              interaction methods.
            </p>
          </div>

          <div className="accessibility-section">
            <h2>Accessible Experience</h2>

            <div className="accessibility-grid">
              <div className="accessibility-card">
                <span className="accessibility-number">01</span>
                <h3>Clear Navigation</h3>
                <p>
                  We aim to keep navigation and important actions clear,
                  consistent and easy to understand.
                </p>
              </div>

              <div className="accessibility-card">
                <span className="accessibility-number">02</span>
                <h3>Readable Content</h3>
                <p>
                  We work to present information in a clear format with
                  appropriate typography, spacing and visual hierarchy.
                </p>
              </div>

              <div className="accessibility-card">
                <span className="accessibility-number">03</span>
                <h3>Visual Accessibility</h3>
                <p>
                  We consider colour contrast, visual clarity and
                  distinguishable interface elements when improving the
                  platform.
                </p>
              </div>

              <div className="accessibility-card">
                <span className="accessibility-number">04</span>
                <h3>Responsive Design</h3>
                <p>
                  IndCasting is designed to provide a usable experience
                  across different screen sizes and devices.
                </p>
              </div>
            </div>
          </div>

          <div className="accessibility-section">
            <h2>Assistive Technologies</h2>
            <p>
              We aim to support users who rely on assistive technologies
              and alternative methods of interacting with digital
              content. Where practical, we work toward semantic
              structures, descriptive labels and meaningful interface
              elements.
            </p>
          </div>

          <div className="accessibility-section">
            <h2>Continuous Improvement</h2>
            <p>
              Accessibility is an ongoing process. As IndCasting
              develops, we will continue reviewing and improving the
              platform to identify areas where the experience can be
              made more inclusive and accessible.
            </p>
          </div>

          <div className="accessibility-section">
            <h2>Feedback &amp; Support</h2>
            <p>
              If you experience difficulty accessing any part of
              IndCasting, we encourage you to let us know. Your feedback
              can help us identify accessibility issues and improve the
              platform for everyone.
            </p>

            <div className="accessibility-contact">
              <span>Accessibility Feedback</span>
              <p>
                Please contact the IndCasting team with details about
                the page or feature you had difficulty accessing and,
                where possible, the issue you encountered.
              </p>
            </div>
          </div>

          <div className="accessibility-section accessibility-last">
            <h2>Our Goal</h2>
            <p>
              Our goal is simple: to make IndCasting a platform where
              creative opportunities are discoverable and accessible to
              everyone.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}