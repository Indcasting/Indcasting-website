import { ImageResponse } from 'next/og'

export const runtime = 'edge'

export const size = { width: 512, height: 512 }
export const contentType = 'image/png'

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#0B0B0B',
          borderRadius: '22%',
        }}
      >
        <svg viewBox="0 0 200 200" width="360" height="360" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F2D77D" />
              <stop offset="50%" stopColor="#C59B27" />
              <stop offset="100%" stopColor="#E8C359" />
            </linearGradient>
            <linearGradient id="spotlight-fade" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#D4AF37" stopOpacity="0" />
            </linearGradient>
          </defs>

          <path d="M 35 -5 L 65 -5 L 70 15 L 30 15 Z" fill="url(#gold)" />
          <polygon points="30,15 70,15 100,120 0,120" fill="url(#spotlight-fade)" />
          <path d="M 25 35 H 75 V 40 H 58 V 160 H 75 V 165 H 25 V 160 H 42 V 40 H 25 Z" fill="url(#gold)" />
          <path d="M 165 45 A 65 65 0 0 0 130 165 A 80 80 0 0 1 165 45 Z" fill="url(#gold)" />
          <path d="M 115 80 Q 115 105 130 105 Q 115 105 115 130 Q 115 105 100 105 Q 115 105 115 80 Z" fill="url(#gold)" />
          
          <path d="M 50 175 Q 120 190 185 125" fill="none" stroke="url(#gold)" strokeWidth="20" />
          <path d="M 50 175 Q 120 190 185 125" fill="none" stroke="#0B0B0B" strokeWidth="12" strokeDasharray="12 10" />
        </svg>
      </div>
    ),
    { ...size }
  )
}
